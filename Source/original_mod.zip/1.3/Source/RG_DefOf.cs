﻿using RimWorld;
using Verse;

namespace RenameGun
{
    [DefOf]
    public static class RG_DefOf
    {
        public static RulePackDef NamerArtWeaponGun;
    }
}
